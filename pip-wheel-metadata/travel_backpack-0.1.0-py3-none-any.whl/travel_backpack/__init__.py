"""travel-backpack - Some very useful functions and classes to use in day-to-day"""

__version__ = '0.1.0'
__author__ = 'Victor Marcelino <victor.fmarcelino@gmail.com>'
__all__ = []
